# virtualBoxにcentos7をインストールするメモ
*  事前にcentos7のminimalのisoイメージをダウンロードしておく
  
以下virtualBoxの操作  
(記憶を頼りに書いているので実際の項目名などが違うかもしれませんがご容赦ください)

* virtualBoxの追加ボタンを押す
    * 名前は適当に(今回はcentos7にした)
    * osタイプは redhat/centos(64bit)
    * メモリは1GB(1024MB)
    *  ストレージは可変(DVI)でサイズは8GB
    * それ以外は特に何もしないで作成
* 起動前に作成したvirtualBox名(今回はcentos7)の上で右クリック->設定
    * ネットワークで2つめのタブでインターフェースの有効のチェックボックスにチェックを入れる
    * interfaceタイプはホストオンリーネットワーク
    * インターフェースの選択はvagrantで使っているのと同じインターフェースを選択する
    * OK押下で閉じる
* 起動
    * 起動したらファイル選択になるのでダウンロードしたisoイメージファイルを選択する
    * Centos7 install(またはtest and centos7 install)
    * textモードでインストールしたい場合は選択された状態で[tab]を押すと下部にコマンドのような行が出てくるここで末尾に " text"を追加して[enter]を押すとテキストモードになる
* 設定内容

    * language=japanse(任意)
    * timeZone=asia/tokyo
    * source=local media
    * package=minimal
    * storage
        * virtualbox-dvi(disk)
        * virtualbox-dvi(slice)
        * all-space
        * LVM
        * standard
    * network
        * hostname=centos7(任意)
        * interface1(enp0s3)
            * ip-addr=dhcp
            * connect=check
            * enable on after reboot=check
        * interface2(enp0s8)
            * ip-addr=192.168.33.100
            * netmask=255.255.255.0
            * connect=check
            * enable on after reboot=check
        * root password=入力する
        * user
            * create user=check
            * user name=適当なuser名
            * use password=check
            * password=入力する
            * admin=check

* 上記すべて設定したらインストール開始する

* インストール後の設定確認  

    * インストール終了後にvagrantからsshログインをしてみる  
        `$ ssh user@192.168.33.100` (認証はパスワード)
    * ログインできたらsudoできるか確認
    * トラブルシューティング

        * sshでつながらなかった場合：ネットワーク設定をしくった可能性あり
             * インストーラー起動前のvirtualBoxのnetwork設定でインターフェースの設定ミス
                 * reboot後にinterfaceを有効にするチェックをしていなかった
                 * ip-addrを間違えた
                 * interface1とinterface2の設定を逆にした
             * などが考えられる
         * sshで認証にはなるがログインできなかった場合
             * create userのチェックをしていなかった
             * パスワードを間違えた
             * user nameを間違えた
             * などが考えられる
         * sudoができなかった場合
            * userのadminにチェックを入れていなかった
            * などが考えられる
      * いずれもosインストール後再設定は可能
      * ただし、ちょっとめんどくさい(ネットワークの設定についてはかなりめんどくさい)

おまけ  
apacheの初期設定(centos7特有の設定項目)

* firewalld無効化
    * しておかないと80番port listenしててもlocalhost以外からアクセスできない

```
$ sudo systemctl stop firewalld
$ sudo systemctl disable firewalld
```

確認
      
```
$ sudo systemctl status firewalld
$ sudo systemctl is-enabled firewalld
```

* selinux無効化
    * しておかないと(サーバーの)外部から(サーバーの)ローカルファイルへのアクセスで403Forbbdenとなる

下記修正後reboot

```
$ sudo vim /etc/selinux/config `
----------------------------------------------------------------------------------------
  # This file controls the state of SELinux on the system.
  # SELINUX= can take one of these three values:
  #     enforcing - SELinux security policy is enforced.
  #     permissive - SELinux prints warnings instead of enforcing.
  #     disabled - No SELinux policy is loaded.
- SELINUX=enforcing
+ SELINUX=disabled
  # SELINUXTYPE= can take one of three values:
  #     targeted - Targeted processes are protected,
  #     minimum - Modification of targeted policy. Only selected processes are protected.
  #     mls - Multi Level Security protection.
  SELINUXTYPE=targeted
----------------------------------------------------------------------------------------
```

以上

