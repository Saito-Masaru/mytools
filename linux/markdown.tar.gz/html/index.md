# php7非対応コードチェックおよびphpの構文チェックツール導入について

### チェックツールについて
* 目的：**新たに追加部分**また**修正部分**について*php7非対応*コードや*推奨されない構文*で書かないようにするため
* ただし、既存のコードの修正の場合、既存コードとの不整合(見た目上おかしくなるかもしれない)という部分をどうするかを決めておく必要がある

## php7非対応コードチェック
### チェックツールの選定
* php7cc
* php7ma
* その他

### php7ccを選定
* 選定理由

## php構文チェックツール
### チェックツールの選定
* phpcs
* その他ツール

### phpcs
* 選定理由
    * php7maなどは実行環境としてphp7.0以上が必要なのでphp5.4で動くphp7ccを選定した
* 考慮事項
    * php7ccはphp7.0への対応しかチェックしてくれない
        * php7.1以降で削除または非推奨となる記述については未対応

## インストール
### インストール環境
* 別vm(ゲストOS)上でセットアップ
    * 経緯：開発環境(ローカルのvagrant(centos5.4))はOSとして古くてSSLルート鍵が足りていないためwget,git等外部とのssl通信が非常に困難なためこの環境で作業するよりもvirtualBox上に別のゲストOSをインストールして作業したほうがよいと判断した
* os: centos7を選定
    * 選定理由
        * 開発環境であるvagrantでのcentos5と同じ系統のcentos
        * yumでインストールされるのdefaultのphpがvagrantと同じphp5.4系
    * [centos7インストールについて](./centos7_install_on_virtualBox.md)

### centos7上での作業
#### phpインストール

```
$ sudo yum install php php-xml php-mbstring
$ php -v
PHP 5.4.16 (cli) (built: Sep  1 2018 05:47:37)
Copyright (c) 1997-2013 The PHP Group
Zend Engine v2.4.0, Copyright (c) 1998-2013 Zend Technologies
```

* php-common,php-zlibなどは上記で同時にインストールされるため省略

#### composerインストール
#### php7ccインストール
#### phpcsインストール
### 開発環境へのインストール
#### centos7での作業
#### 開発環境での作業

### 使用方法
### 運用について

-------------------------------------------------------------------------

### markdownについて
当ドキュメントはmarkdownで記述しました。  
インストール手順や運用手順、仕様書等の開発ドキュメントについてはmarkdownで記述することをお勧めします。  
推奨理由を含めて[markdownについて](about-markdown.md)をまとめました  
### markdown表示機能について
* [parsedownn](https://github.com/erusev/parsedown)を使うことにした
    * 他の候補、選定理由については[こちら](./markdown_choice.md)にまとめた

### インストール方法
* 対象ディレクトリ：/path/to/documentRoot/markdown とする

```
$ mkdir -p /path/to/documentRoot/markdown
$ cd /path/to/documentRoot/markdown
$ git clone https://github.com/erusev/parsedown.git
$ mv parsedown .parsedown
$ cd .parsedown
$ composer install
```
* markdownの表示処理をするサーバーとインストール処理をするサーバが異なる場合は.parsedownディレクトリごと他のサーバに移せば問題ない
* ディレクトリ名の頭に"."を入れたのはindexファイルを置かなかった場合にファイル一覧を表示しても表示されないようにするため
    * 直接アクセスすることは可能

#### apacheの設定
* /path/to/documentRoot/markdown以下で**.htaccess**を使えるように設定する
* その他の設定は省略する

```
<Directory "/path/to/documentRoot/markdown">
    Require all granted
    # apache2.2系の場合
    #Order allow,deny
    #Allow from All
    AllowOverride All
</Directory>
```

* .htaccessの内容

`/path/to/documentRoot/markdown/.htaccess`

```
DirectoryIndex index.html index.php index.md
AddType text/markdown md
Action text/markdown /markdown/.parsedown/md.php
```

* directory indexに*index.md*を追加
* `*.md`へのリクエストは`/markdowm/.parsedown/md.php`に処理させる

#### md.phpの中身

```
<?php
require __DIR__.'/vendor/autoload.php';
$file_path = $_SERVER['PATH_TRANSLATED'];
echo file_get_contents($file_path);
```

実際にはエラー処理やcssを使うなど追加の処理は入っているがmarkdownを表示するための最低限の処理は上記のようになっている

以上
