# parsedownについて
### parsedownとは
### 基本的な使い方
### pasedownでできない(本当はできるのかもしれない)こと
* 相対リンク
    * parsedownのデフォルト設定ではできない
    * たぶん何かの設定Set系のメソッドとかで回避できると思うがまだ解析途中
* 外部markdownファイルのインクルード
    * いくつかドキュメントを書いていると全く同じ内容を違うmarkdownドキュメント内で使いたいということがあるが、現状markdownにはそのような機能は(たぶん)ない。
    * ただし、pasedownを使ってなんちゃって的にそれっぽくすることはできなくもない

```
document1.php

  <?php
  require '/path/to/dir/vendor/autoload.php';
  $Parsedown = new Parsedown();
  echo $Parsedown->text(file_get_contents('document1.md'));
  echo $Parsedown->text(file_get_contents('include.md'));


document2.php

  <?php
  require '/path/to/dir/vendor/autoload.php';
  $Parsedown = new Parsedown();
  echo $Parsedown->text(file_get_contents('document2.md'));
  echo $Parsedown->text(file_get_contents('include.md'));
```

* これで納得できるかは別問題。。。 

### markdown記法について

markdownの書き方については慣れるまでは若干時間がかかるかもしれないのでつまり易い箇所を箇条書きにしてみる
* (markdownで使っている)記号の直後にホワイトスペースを入れる
* (markdownで使っている)記号の見出し、リスト等は行頭から書く(前にスペースを入れない)
* リストのスペースはtabで入れると楽
    * tabを打つと4つのスペースになるようにエディタを設定してるとさらに楽
* 行末に2つのホワイトスペースを入れることで改行あつかいになる
    * 入れないとつながってしまう
* コード(```)の前後は空行にする
* テーブル
    * 段組み行"|----|----|"、"|:---|:---:|:---|"などの行はパイプ"|"の前後にスペースを入れない
    * 段組み行のハイフンは最低3個以上連続でつなげる必要がある(多いぶんには(常識の範囲内で)問題ない)
    * ヘッダー行およびデータ行のカラムの区切り("|")の前後にはホワイトスペースを入れる
    * カラムの内部に改行を入れたい場合は窮屈だが1行の中で記載して行区切りとして<br\>or<br/\>を書く
    * 横のカラムとの連結はできない(markdownの制約事項)
    * 両端のパイプ"|"はあってもなくても同じ(どちらでもよい)
    * テーブルの前後は空行にする
* 強調文字は\*で囲むと*strong*となる
* その他文字装飾については[markdown記法](https://www.google.com/search?q=markdown記法&rlz=1C1GCEU_jaJP862JP862&oq=markdown記法&aqs=chrome..69i57j0l4j69i61.28263j0j7&sourceid=chrome&ie=UTF-8)について詳しく書かれているページがあるのでそちらを参照
* 見た目の変更をしたい場合はcssを当てることで多少変更可能
    * ただし、同じ記法は同じになるので繊細な（divタグのclass名のような)表現の切り分けは難しい


