# phpにおけるmarkdownライブラリの選定

### 1. 経緯

* ドキュメントをmarkdownで書いていきながらHTML変換をして確認をしている際に期待していたHTML表記になっていないケースがあったため適切なライブラリを選定することにした

### 2. 選定リスト
* php-markdown <https://github.com/michelf/php-markdown>
* cebe/markdown <https://github.com/cebe/markdown>
* parsedown <https://github.com/erusev/parsedown>

### 3. 評価

|               | php-markdown | cebe/markdown | parsedown |
|:--------------|:-------------|:--------------|:----------|
| 評価する点    | google検索で最も上位に出てくる | php-markdownよりは若干良い(ほぼ誤差) | tableが利用可能<br/>code中の'#'の扱いが直感的に利用可能 |
| 評価しない点  | ・tableが利用できない<br/>・codeの内部の空白の扱いが意図したものと違う<br/>・code中の'#'が見出しと評価されてしまう<br/>・codeの途中に空行を入れられない | ・概ねphp-markdownと同じ<br/>・違いはcode中の空白の扱いは意図したとおりに反映される | googleやqiitaなどで上位に出てこない |
| テスト用評価ページ<br/>同じファイル(シンボリックリンク) | [php-markdown](/php-markdown/) | [markdown](/markdown/) | [parsedown](/parsedown/) |
| 総合評価      | ×           | ×          | 〇          |

### 4. 結論

parsedownにすることにした

### 補足

cebe/markdown、php-markdown共にextra markdownというものがありそれを使えばtable等は対応するようになるのかもしれないが、  
そもそもtable程度は標準でサポートしているべきと思うので特に減少はしない。

### おまけ

markdownに適切なcssを検討

 No | 確認ページリンク | 補足
----|------------------|-----
1   | (css1)[/css1/] |
2   | </css2/> |
3   | </css3/> |
4   | </css4/> |
5   | </css5/> |

(css1)[/css1/]  
</css1/index.md>



